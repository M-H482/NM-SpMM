bash run_bench.sh | tee data.txt
python3 plot.py