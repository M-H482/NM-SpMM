#!/bin/bash

exe_v0_=./v0_naive
exe_v1_=./v1_block_tiling
exe_v2_=./v2_warp_thread_tiling
exe_v3L=./v3_sparsity_aware_low_sparsity
exe_v3H=./v3_sparsity_aware_high_sparsity
exe_v4L=./v4_prefetch_low_sparsity 
exe_v4H=./v4_prefetch_high_sparsity 

# m=4096; n=4096; k=4096; 
# echo "sparsity = 0%"
# s=0; scale=1;
# tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

# echo "sparsity = 50.0%"
# s=0.5; scale=2;
# tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

# echo "sparsity = 62.5%"
# s=0.625; scale=2.666666;
# tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

# echo "sparsity = 75%"
# s=0.75; scale=4;
# tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v3H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v4H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

# echo "sparsity = 87.5%"
# s=0.875; scale=8;
# tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v3H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
# tflops=$($exe_v4H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
# echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

m=8192; n=8192; k=8192; 
echo "sparsity = 0%"
s=0; scale=1;
tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

echo "sparsity = 50.0%"
s=0.5; scale=2;
tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

echo "sparsity = 62.5%"
s=0.625; scale=2.666666;
tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v3L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v4L  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

echo "sparsity = 75%"
s=0.75; scale=4;
tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v3H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v4H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc

echo "sparsity = 87.5%"
s=0.875; scale=8;
tflops=$($exe_v0_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v1_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v2_  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v3H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc
tflops=$($exe_v4H  $m $n $k 32 $s | grep TFLOPS | cut -d ' ' -f 5)
echo "scale=6; 100 * $tflops / 19.5 / $scale" | bc